# Micro-level audit — v98.63.9.30


## Video observations
1. A floating `+`/More button remained visible in the scientific matrix and opened a secondary panel. User requested no plus control.
2. INV changed only the three trigonometric labels/tokens; logarithmic, exponential, root, and power pairs remained primary.
3. The scientific panel keys needed a consistent 20px baseline.
4. The main keypad surface needed a 20px height/basis reduction while scientific functions were open.

## Changes
- Removed `sci-more-toggle` and the `sci-more-functions` markup and event logic.
- Replaced the final matrix slot with cube-root `∛`, inverse-paired to `x³`.
- Added INV label/token pairs for ln/eˣ, log/10ˣ, √/x², ∛/x³, and xʸ/x⁻ʸ in addition to inverse trig.
- Constants and functions without a defined reciprocal/inverse pairing are intentionally unchanged by INV.
- Added a last-layer CSS correction for 20px scientific controls and a 20px keypad surface reduction while overlay is open.
- Updated root/Android web copies and release identity/cache namespace.

## Validation scope
Source checks, calculator numeric regression, HTML key-map assertions, web production bundle, and ZIP integrity were tested. Actual APK build and physical Android interaction remain unverified in this environment.
