# QA Results — v98.63.9.31

## Release verification
- Source package: `1.98.78-v98.63.9.31`
- Android versionCode: `1098079`
- Tools keypad reference: `Screenrecording_20261122_105224.mp4` (720×1560)

## Automated checks
- `npm test`: 45 passed, 0 failed.
- Tool keypad reference regression: passed (included in `npm test`).
- JavaScript syntax: passed.
- Android web bundle generation: passed.
- ZIP archive integrity: passed.
- Workflow YAML syntax: passed.

## Action preflight correction
The v98.63.9.31 workflow required this report but the source archive did not contain it:
`QA-RESULTS-v98.63.9.31.md`.
That mismatch would stop GitHub Actions in the "Verify source files and project configuration" step before dependency installation or Android build. This report is now included in the source package, and a regression test checks that every workflow-required file exists before release packaging.

## Device-level limitation
CI checks do not replace installing the generated APK on a physical Android device. OEM Back dispatch, safe-area insets, WebView touch timing, and visual dimensions still require a device run.
