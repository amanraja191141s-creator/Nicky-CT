# v98.63.9.28 CI workflow source-check fix

## Root cause
The Android workflow hard-required `MICRO-LEVEL-AUDIT-v98.63.9.28.md` while the project contained the same release audit as `MICRO-AUDIT-v98.63.9.28.md`. This filename-only mismatch caused the CI job to exit before SDK, dependency, web-build, regression, sync, or APK steps ran.

## Correction
- CI accepts either of the two `.28` audit filename variants.
- It still fails if both are missing or empty.
- Exact version/archive selection and all other required source-file checks remain strict.
- Root workflow and standalone YML are synchronized.
- Added regression test for the filename compatibility rule.

## Verification
- `npm test`: 74 tests passed.
- `npm run build:web`: passed; 13 required web assets verified.
- Workflow required-file checks simulated: passed.
- JavaScript syntax checks passed.
- ZIP integrity checked after packaging.
- Android APK build/device run not performed locally; CI should continue into those steps now that the early source-check blocker is removed.
