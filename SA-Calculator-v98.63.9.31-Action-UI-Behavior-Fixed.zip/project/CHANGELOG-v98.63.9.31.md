# Changelog — v98.63.9.31

## Video-matched Tools keypad and input behaviour
- Replaced the dimmed modal keypad overlay with one docked, bottom-anchored numeric keypad shared by tool screens.
- The keypad stays hidden on tool entry and opens only when an editable numeric field is tapped.
- Tapping another numeric field retargets the same keypad without closing or opening a second keyboard.
- Reproduced the reference four-column key order: 7–9/AC, 4–6/backspace, 1–3/tall equals, then 00/0/decimal.
- Equals recalculates the active tool, persists the current inputs, and dismisses the keypad.
- Tool forms remain scrollable above the keyboard; lower focused fields are scrolled into view.
- Navigation, Escape/system Back, and tool changes dismiss the keypad; no native Android numeric keyboard is requested.
- Added missing Age, Salary, and SIP destinations to the Favorites registry.
- Updated the release identity to `1.98.78-v98.63.9.31` and Android versionCode `1098079`.
