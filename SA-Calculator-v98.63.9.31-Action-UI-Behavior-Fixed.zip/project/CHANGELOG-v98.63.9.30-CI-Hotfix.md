# CI Hotfix — v98.63.9.30

- Cause: CI hard-coded the v29 cache token but v30 source uses its v30 namespace.
- Workflow now derives the cache namespace from selected source and verifies generated `www/service-worker.js` includes the same namespace.
- Added regression coverage to the release test command.
- Synced duplicate workflow copies. App runtime, package version, and Android versionCode are unchanged.

- Found and corrected a second source-check typo: workflow now requires the existing `tests/v98634-marked-screenshot-cleanup.test.mjs` instead of the missing marked-calculator-boundary filename.
