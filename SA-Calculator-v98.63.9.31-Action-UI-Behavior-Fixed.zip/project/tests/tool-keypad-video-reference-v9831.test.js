'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const js = fs.readFileSync(path.join(root, 'assets/js/app.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'assets/css/app.css'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');

test('tool numeric keypad is docked, non-modal, and hidden until a numeric field is selected', () => {
  assert.match(html, /id="popup-keypad-sheet"[^>]*aria-label="Numeric keypad"/);
  assert.match(css, /#popup-keypad-overlay,[\s\S]*?display:none!important/);
  assert.match(css, /#popup-keypad-sheet:not\(\.active\)[\s\S]*?visibility:hidden!important/);
  assert.match(css, /#popup-keypad-sheet\.active[\s\S]*?position:fixed!important/);
  assert.match(css, /height:min\(49dvh,760px\)!important/);
  assert.match(js, /document\.body\.classList\.add\('tool-keypad-active'\)/);
  assert.match(js, /document\.body\.classList\.remove\('tool-keypad-active'\)/);
  assert.match(js, /window\.history\.pushState\(\{ saToolKeypad: true \}/);
  assert.match(js, /closePopupKeypad\(true\)/);
  assert.match(js, /window\.history\.back\(\)/);
});

test('keypad layout matches the four-column reference with a two-row equals key', () => {
  for (const key of ['7','8','9','CLR','4','5','6','DEL','1','2','3','EQUAL','00','0','.']) {
    assert.match(html, new RegExp(`data-popup="${key}"`));
  }
  assert.match(css, /grid-template-columns:repeat\(4,minmax\(0,1fr\)\)!important/);
  assert.match(css, /grid-template-rows:repeat\(4,minmax\(0,1fr\)\)!important/);
  assert.match(css, /grid-row:3 \/ span 2!important/);
  assert.doesNotMatch(html, /data-popup="NEXT"|data-popup="DONE"/);
});

test('equals calculates the active tool and closes the docked keypad', () => {
  const equalBranch = js.slice(js.indexOf("if (key === 'EQUAL')"), js.indexOf("} else if (key === 'CLR')", js.indexOf("if (key === 'EQUAL')")));
  assert.match(equalBranch, /recalculateCurrentScreen\(\)/);
  assert.match(equalBranch, /persistPreviousInputs\(\)/);
  assert.match(equalBranch, /closePopupKeypad\(\)/);
});
