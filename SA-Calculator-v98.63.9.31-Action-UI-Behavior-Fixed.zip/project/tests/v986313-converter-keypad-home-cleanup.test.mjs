import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve(import.meta.dirname, '..');
const js = fs.readFileSync(path.join(root, 'assets/js/app.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'assets/css/app.css'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
test('converter keypad labels are explicit and never read option inventory text', () => {
  assert.match(js, /'unit-input-val': 'Value'/);
  assert.match(js, /'cur-amount': 'Amount'/);
  assert.match(js, /'cur-to-amount': 'Converted amount'/);
  assert.match(js, /!node\.querySelector\('select, option, input, textarea, button'\)/);
  assert.match(js, /sheet\.dataset\.keypadContext = inputElem\.id/);
});
test('legacy home header is removed from calculator-first surface only', () => {
  assert.match(css, /body:has\(#screen-viewport > #screen-calc\.active\) header\.app-header\s*\{\s*display:\s*none !important/);
  assert.match(html, /<div class="screen active" id="screen-calc">/);
  assert.match(html, /data-bottom-nav="calc"[^>]*>[\s\S]*?Calculator/);
});
test('converter selected controls and numeric dock keypads remain present', () => {
  for (const id of ['cur-from','cur-to','unit-from','unit-to','unit-input-val']) assert.match(html, new RegExp(`id="${id}"`));
  assert.match(html, /class="dock-keypad currency-dock-keypad"/);
  assert.match(html, /id="screen-units"[\s\S]*?class="dock-keypad"/);
});
