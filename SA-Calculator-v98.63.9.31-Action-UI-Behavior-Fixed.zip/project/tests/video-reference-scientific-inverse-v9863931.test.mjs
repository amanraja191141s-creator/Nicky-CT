import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const css=fs.readFileSync(path.join(root,'assets/css/app.css'),'utf8');
const js=fs.readFileSync(path.join(root,'assets/js/app.js'),'utf8');
const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
const workflow=fs.readFileSync(path.join(root,'.github/workflows/main.yml'),'utf8');
test('v98.63.9.31 scientific grid removes plus/secondary panel and keeps 16 cells',()=>{
 const grid=html.match(/<div class="scientific-function-grid"[^>]*>([\s\S]*?)<\/div>/)?.[1]||'';
 assert.ok(grid,'scientific grid missing');
 assert.equal((grid.match(/<button/g)||[]).length,16,'must be exactly 16 function-grid buttons');
 assert.doesNotMatch(html,/id="sci-more-toggle"|id="sci-more-functions"|More scientific functions|>＋</);
 assert.ok(grid.includes('data-sci-insert="cbrt("')); assert.ok(grid.includes('data-sci-alt-label="x³"'));
});
test('INV provides inverse alternatives for trig, logs, exponentials, roots and powers',()=>{
 const buttons=[...html.matchAll(/<button[^>]*data-sci-insert=[\"']([^\"']+)[\"'][^>]*>([^<]*)<\/button>/g)].map(m=>({tag:m[0],token:m[1],label:m[2]}));
 const pairs=[
 ['sin(','asin(','sin','sin⁻¹'],['cos(','acos(','cos','cos⁻¹'],['tan(','atan(','tan','tan⁻¹'],
 ['ln(','2.718281828459045^(','ln','eˣ'],['log(','10^(','log','10ˣ'],
 ['2.718281828459045^(','ln(','eˣ','ln'],['sqrt(','^2','√','x²'],
 ['10^(','log(','10ˣ','log'],['^2','sqrt(','x²','√'],['^','^(-','xʸ','x⁻ʸ'],['cbrt(','^3','∛','x³']
 ];
 for(const [primary,alt,label,altLabel] of pairs){
  const btn=buttons.find(x=>x.token===primary); assert.ok(btn,`missing primary ${primary}`);
  assert.ok(btn.tag.includes(`data-sci-alt-insert=\"${alt}\"`),`missing alt token ${alt} for ${primary}`);
  assert.ok(btn.tag.includes(`data-sci-label=\"${label}\"`),`missing base label ${label}`);
  assert.ok(btn.tag.includes(`data-sci-alt-label=\"${altLabel}\"`),`missing inverse label ${altLabel}`);
 }
 assert.match(js,/data-sci-alt-insert/); assert.match(js,/aria-pressed/); assert.match(js,/insertScientificIntoMain\(token\)/);
});
test('video size correction reduces main keypad surface by 20px and scientific font to 20px minimum',()=>{
 const layer=css.slice(css.lastIndexOf('v98.63.9.31 — remove floating More'));
 assert.match(layer,/calc\(var\(--main-keypad-basis,64%\) - 20px\)/);
 assert.match(layer,/font-size:clamp\(20px,5vw,24px\)!important/);
 assert.match(layer,/font-size:20px!important/);
});
test('release identities, workflow and mirrored web files are current and aligned',()=>{
 assert.equal(pkg.version,'1.98.78-v98.63.9.31'); assert.equal(pkg.androidVersionCode,1098079);
 assert.match(html,/1\.98\.78-v98\.63\.9\.31/); assert.match(workflow,/v98\.63\.9\.31/); assert.match(workflow,/1098079/);
 assert.equal(fs.readFileSync(path.join(root,'www/index.html'),'utf8'),html);
 assert.equal(fs.readFileSync(path.join(root,'www/assets/js/app.js'),'utf8'),js);
 assert.equal(fs.readFileSync(path.join(root,'www/assets/css/app.css'),'utf8'),css);
});
