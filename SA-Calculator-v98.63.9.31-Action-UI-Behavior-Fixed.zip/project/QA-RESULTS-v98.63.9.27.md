# QA results — v98.63.9.27


- Release tests: **68 passed, 0 failed**.
- `npm run build:web`: **PASS**, 13 required assets verified.
- ZIP integrity: **PASS**.
- Package version: `1.98.74-v98.63.9.27`.
- Android versionCode: `1098075`.
- Main workflow and standalone YML: **identical**.
- Visual/device testing: **not performed**.
- Android APK compilation/install: **not performed**.
